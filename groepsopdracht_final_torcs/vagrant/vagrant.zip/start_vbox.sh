#!/usr/bin/env bash
# Author: J.A.Boogaard@hr.nl

echo "Start VirtualBox torcs-server"
vagrant up --provider=virtualbox && vagrant status