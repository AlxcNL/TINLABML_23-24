#!/usr/bin/env bash
# Author: J.A.Boogaard@hr.nl

box="torcs-server"
echo "Start VirtualBox $box"
vagrant down $obx
vagrant status